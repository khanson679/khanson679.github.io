/* Class A Fixed*/

#ifndef A_
#define A_

class A{
//...
};

#endif