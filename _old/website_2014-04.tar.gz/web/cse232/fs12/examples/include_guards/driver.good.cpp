/* User */

#include �a.good.h�
#include �b.good.h� //no error this time

int main() {return 0;}