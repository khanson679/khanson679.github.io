/* User */

#include �a.bad.h�
#include �b.bad.h� //you will get an error

int main() {return 0;}