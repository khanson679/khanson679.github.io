/* Class B Fixed */

#ifndef B_
#define B_

#include �classA.h�

class B{
//...
};

#endif