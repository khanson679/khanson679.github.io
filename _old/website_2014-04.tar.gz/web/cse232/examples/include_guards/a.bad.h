/* Class A */

class A{
//...
};